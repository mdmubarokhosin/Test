'use client';

import { useState, useEffect } from 'react';
import { Lock, Eye, EyeOff, ArrowLeft, Loader2, User, UserPlus, Mail, ShieldCheck, AlertTriangle } from 'lucide-react';
import { useAppStore } from '@/store/app-store';
import { navigateTo } from '@/lib/navigate';
import { useTranslation } from '@/lib/i18n-context';
import { LanguageSwitcher } from '@/components/madrasa/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

type LoginMode = 'login' | 'register';

export default function AdminLogin() {
  // NO loading/checking screen — the login form renders instantly.
  // When the existence check resolves: no admin yet → swap to registration;
  // admin exists → stay on login. Zero flash, zero progress gate.
  const [mode, setMode] = useState<LoginMode>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  // Registration form state
  const [regName, setRegName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirm, setRegConfirm] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);

  const { adminLogin, registerAdmin, checkAdminExists, isLoggingIn } = useAppStore();
  const { t } = useTranslation();

  // On load: decide whether to show login or first-admin registration
  useEffect(() => {
    let cancelled = false;
    checkAdminExists().then((exists) => {
      if (!cancelled) setMode(exists ? 'login' : 'register');
    });
    return () => {
      cancelled = true;
    };
  }, [checkAdminExists]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password.trim()) {
      setError(t('adminLogin.bothRequired'));
      return;
    }

    const success = await adminLogin(username.trim(), password);
    if (!success) {
      setError(t('admin.wrongPassword'));
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!regName.trim() || !regUsername.trim() || !regEmail.trim() || !regPassword || !regConfirm) {
      setError(t('adminRegister.allFieldsRequired'));
      return;
    }
    if (regUsername.trim().length < 3) {
      setError(t('adminRegister.usernameShort'));
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(regEmail.trim())) {
      setError(t('adminRegister.emailInvalid'));
      return;
    }
    if (regPassword.length < 6) {
      setError(t('adminRegister.passwordShort'));
      return;
    }
    if (regPassword !== regConfirm) {
      setError(t('adminRegister.passwordMismatch'));
      return;
    }

    const result = await registerAdmin(regName.trim(), regUsername.trim(), regEmail.trim(), regPassword);
    if (!result.ok) {
      setError(
        result.error === 'already-exists'
          ? t('adminRegister.alreadyExists')
          : result.error === 'email-in-use'
            ? t('adminRegister.emailInUse')
            : t('adminRegister.failed')
      );
      if (result.error === 'already-exists') {
        // An admin was created meanwhile — switch to login mode
        setMode('login');
      }
    }
    // On success the store switches currentView to 'admin' automatically
  };

  const sharedFieldClass = 'ps-10 h-11 rounded-xl bg-white/5 border-white/15 text-white placeholder:text-white/35 focus-visible:border-gold-soft/60 focus-visible:ring-gold-soft/40';

  const isRegister = mode === 'register';

  return (
    <div className="min-h-screen geo-dark">
      {/* Single in-flow wrapper (geo-dark forces in-flow children to relative/z-1),
          decorations anchor to it; m-auto centering avoids top-clipping on short screens */}
      <div className="relative flex w-full min-h-screen px-4 py-10 overflow-hidden">
        {/* Faint giant rotating 8-point star */}
        <svg
          viewBox="0 0 100 100"
          aria-hidden="true"
          className="animate-spin-slow absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[36rem] h-[36rem] text-gold-soft/5 pointer-events-none"
        >
          <path
            d="M50 2 L59 26 L83 17 L74 41 L98 50 L74 59 L83 83 L59 74 L50 98 L41 74 L17 83 L26 59 L2 50 L26 41 L17 17 L41 26 Z"
            stroke="currentColor"
            strokeWidth={0.75}
            fill="none"
          />
          <circle cx="50" cy="50" r="14" stroke="currentColor" strokeWidth={0.75} fill="none" />
          <circle cx="50" cy="50" r="5" fill="currentColor" />
        </svg>

        {/* Gold radial glow (top) */}
        <div
          aria-hidden="true"
          className="absolute -top-48 inset-x-0 mx-auto w-[46rem] h-[26rem] rounded-full bg-gold-bright/10 blur-[110px] pointer-events-none"
        />

        {/* Very top gold flow line */}
        <div aria-hidden="true" className="gold-flow-line absolute top-0 inset-x-0" />

        {/* Glass panel card */}
        <div className="relative m-auto w-full max-w-md rounded-3xl border border-gold-soft/15 bg-white/[0.04] backdrop-blur-xl p-8 shadow-2xl">
          {/* Card top gold flow strip */}
          <div aria-hidden="true" className="gold-flow-line absolute top-0 inset-x-0 rounded-t-3xl" />

          {/* Language switcher — pinned to the panel's top-end corner so it
              stays clear of the centered logo/title in BOTH modes (login and
              first-admin registration) */}
          <div className="absolute top-4 end-4 z-10">
            <LanguageSwitcher compact onDark />
          </div>

          {/* Logo in gold-ringed circle */}
          <div className="flex flex-col items-center gap-4 pb-6">
            <div className="p-1 rounded-full bg-gradient-to-br from-gold-soft to-gold-bright shadow-lg shadow-gold-bright/25">
              <div className="bg-night rounded-full p-2">
                <img
                  src="/logo.png"
                  alt={t('adminLayout.subtitle')}
                  className="w-16 h-16 object-contain rounded-full"
                />
              </div>
            </div>

            {/* Title */}
            <div className="text-center space-y-1.5">
              <h1 className="text-2xl font-bold text-white tracking-tight">
                {isRegister ? t('adminRegister.title') : t('admin.adminPanel')}
              </h1>
              <div className="ornament-divider text-gold-soft/70 text-sm py-1 px-6" aria-hidden="true">
                <span>✦</span>
              </div>
              <p className="text-white/55 text-sm">
                {isRegister ? t('adminRegister.subtitle') : t('adminLayout.subtitle')}
              </p>
            </div>
          </div>

          {isRegister ? (
            /* ---------------- First-admin registration form ---------------- */
            <form onSubmit={handleRegister} className="space-y-5">
              {/* Setup notice */}
              <div className="bg-gold-soft/10 border border-gold-soft/25 text-gold-soft/90 px-4 py-3 rounded-xl text-sm flex gap-2.5 items-start" role="note">
                <ShieldCheck className="size-4 mt-0.5 shrink-0 text-gold-bright" aria-hidden="true" />
                <span>{t('adminRegister.setupNote')}</span>
              </div>

              {/* Name field */}
              <div className="space-y-2">
                <label htmlFor="admin-reg-name" className="text-sm font-medium text-white/75">
                  {t('adminRegister.name')}
                </label>
                <div className="relative">
                  <User className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-white/35" />
                  <Input
                    id="admin-reg-name"
                    type="text"
                    value={regName}
                    onChange={(e) => {
                      setRegName(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder={t('adminRegister.namePlaceholder')}
                    className={sharedFieldClass}
                    disabled={isLoggingIn}
                    autoComplete="name"
                  />
                </div>
              </div>

              {/* Username field */}
              <div className="space-y-2">
                <label htmlFor="admin-reg-username" className="text-sm font-medium text-white/75">
                  {t('adminNav.username')}
                </label>
                <div className="relative">
                  <UserPlus className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-white/35" />
                  <Input
                    id="admin-reg-username"
                    type="text"
                    value={regUsername}
                    onChange={(e) => {
                      setRegUsername(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder={t('adminLogin.usernamePlaceholder')}
                    className={sharedFieldClass}
                    disabled={isLoggingIn}
                    autoComplete="username"
                  />
                </div>
              </div>

              {/* Email field (Firebase Auth account) */}
              <div className="space-y-2">
                <label htmlFor="admin-reg-email" className="text-sm font-medium text-white/75">
                  {t('adminRegister.email')}
                </label>
                <div className="relative">
                  <Mail className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-white/35" />
                  <Input
                    id="admin-reg-email"
                    type="email"
                    value={regEmail}
                    onChange={(e) => {
                      setRegEmail(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder={t('adminRegister.emailPlaceholder')}
                    className={sharedFieldClass}
                    disabled={isLoggingIn}
                    autoComplete="email"
                  />
                </div>
              </div>

              {/* Password field */}
              <div className="space-y-2">
                <label htmlFor="admin-reg-password" className="text-sm font-medium text-white/75">
                  {t('admin.password')}
                </label>
                <div className="relative">
                  <Lock className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-white/35" />
                  <Input
                    id="admin-reg-password"
                    type={showRegPassword ? 'text' : 'password'}
                    value={regPassword}
                    onChange={(e) => {
                      setRegPassword(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder={t('admin.passwordPlaceholder')}
                    className="ps-10 pe-10 h-11 rounded-xl bg-white/5 border-white/15 text-white placeholder:text-white/35 focus-visible:border-gold-soft/60 focus-visible:ring-gold-soft/40"
                    disabled={isLoggingIn}
                    autoComplete="new-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword(!showRegPassword)}
                    className="absolute end-3 top-1/2 -translate-y-1/2 text-white/45 hover:text-gold-soft transition-colors"
                    aria-label={showRegPassword ? t('adminLogin.hidePassword') : t('adminLogin.showPassword')}
                    disabled={isLoggingIn}
                  >
                    {showRegPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
              </div>

              {/* Confirm password field */}
              <div className="space-y-2">
                <label htmlFor="admin-reg-confirm" className="text-sm font-medium text-white/75">
                  {t('adminRegister.confirmPassword')}
                </label>
                <div className="relative">
                  <Lock className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-white/35" />
                  <Input
                    id="admin-reg-confirm"
                    type={showRegPassword ? 'text' : 'password'}
                    value={regConfirm}
                    onChange={(e) => {
                      setRegConfirm(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder={t('admin.passwordPlaceholder')}
                    className={sharedFieldClass}
                    disabled={isLoggingIn}
                    autoComplete="new-password"
                  />
                </div>
              </div>

              {/* Error message */}
              {error && (
                <div className="bg-danger/10 border border-danger/40 text-danger px-4 py-3 rounded-xl text-sm animate-fade-in-up" role="alert">
                  {error}
                </div>
              )}

              {/* Register button */}
              <Button
                type="submit"
                className="btn-gold w-full h-12 rounded-full font-bold text-base"
                disabled={isLoggingIn}
              >
                {isLoggingIn ? (
                  <>
                    <Loader2 className="size-5 animate-spin" />
                    <span>{t('adminRegister.creating')}</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="size-5" />
                    <span>{t('adminRegister.createButton')}</span>
                  </>
                )}
              </Button>
            </form>
          ) : (
            /* ---------------- Existing admin login form ---------------- */
            <form onSubmit={handleLogin} className="space-y-5">
              {/* Username field */}
              <div className="space-y-2">
                <label htmlFor="admin-username" className="text-sm font-medium text-white/75">
                  {t('adminNav.username')}
                </label>
                <div className="relative">
                  <User className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-white/35" />
                  <Input
                    id="admin-username"
                    type="text"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder={t('adminLogin.identifierPlaceholder')}
                    className={sharedFieldClass}
                    disabled={isLoggingIn}
                    autoFocus
                    autoComplete="username"
                  />
                </div>
              </div>

              {/* Password field */}
              <div className="space-y-2">
                <label htmlFor="admin-password" className="text-sm font-medium text-white/75">
                  {t('admin.password')}
                </label>
                <div className="relative">
                  <Lock className="absolute start-3 top-1/2 -translate-y-1/2 size-4 text-white/35" />
                  <Input
                    id="admin-password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder={t('admin.passwordPlaceholder')}
                    className="ps-10 pe-10 h-11 rounded-xl bg-white/5 border-white/15 text-white placeholder:text-white/35 focus-visible:border-gold-soft/60 focus-visible:ring-gold-soft/40"
                    disabled={isLoggingIn}
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute end-3 top-1/2 -translate-y-1/2 text-white/45 hover:text-gold-soft transition-colors"
                    aria-label={showPassword ? t('adminLogin.hidePassword') : t('adminLogin.showPassword')}
                    disabled={isLoggingIn}
                  >
                    {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
              </div>

              {/* Error message */}
              {error && (
                <div className="bg-danger/10 border border-danger/40 text-danger px-4 py-3 rounded-xl text-sm animate-fade-in-up" role="alert">
                  <span className="flex items-center gap-2">
                    <AlertTriangle className="size-4 shrink-0" aria-hidden="true" />
                    {error}
                  </span>
                </div>
              )}

              {/* Login button */}
              <Button
                type="submit"
                className="btn-gold w-full h-12 rounded-full font-bold text-base"
                disabled={isLoggingIn}
              >
                {isLoggingIn ? (
                  <>
                    <Loader2 className="size-5 animate-spin" />
                    <span>{t('admin.verifying')}</span>
                  </>
                ) : (
                  <>
                    <Lock className="size-5" />
                    <span>{t('admin.loginButton')}</span>
                  </>
                )}
              </Button>

              {/* Password hint */}
              <div className="text-center">
                <p className="text-xs text-white/50 bg-white/5 border border-white/10 rounded-xl px-3 py-2 inline-block">
                  {t('adminLogin.legalNotice')} <span className="font-mono font-medium text-gold-soft">{t('adminLogin.legalAction')}</span>
                </p>
              </div>
            </form>
          )}

          {/* Back to website link */}
          <div className="mt-8 pt-5 border-t border-white/10">
            <button
              type="button"
              onClick={() => navigateTo('public')}
              className="w-full flex items-center justify-center gap-2 text-sm text-gold-soft/80 hover:text-gold-soft transition-colors py-2 rounded-xl hover:bg-white/5"
            >
              <ArrowLeft className="size-4 rtl:-scale-x-100" />
              <span>{t('admin.backToSite')}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
