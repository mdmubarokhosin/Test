#!/usr/bin/env bash
# Self-healing dev server supervisor: restarts next dev if it dies.
cd /home/z/my-project
export NODE_OPTIONS=--max-old-space-size=1450
while true; do
  echo "[$(date '+%H:%M:%S')] starting next dev..." >> dev.log
  node_modules/.bin/next dev --webpack -p 3000 >> dev.log 2>&1
  echo "[$(date '+%H:%M:%S')] next dev exited, restarting in 2s" >> dev.log
  sleep 2
done
