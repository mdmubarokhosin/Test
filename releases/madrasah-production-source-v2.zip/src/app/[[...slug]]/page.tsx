// Server component wrapper for catch-all SPA route
// generateStaticParams runs at build time to pre-render HTML for all routes
// The actual client-side SPA logic lives in ./_client-page.tsx

import ClientPage from './_client-page';

// In production builds dynamicParams=false: only the slugs enumerated in
// generateStaticParams() are prerendered; the host's `/* /index.html 200`
// rewrite in public/_redirects serves every deep link. In dev it is true:
// unenumerated paths render this SPA dynamically so the app's own styled 404
// + noindex logic runs — instead of the Next 16 E443 "missing param ... with
// output: export" crash that turns first unknown requests into 404s and all
// subsequent ones into HTTP 500s.
export const dynamicParams = process.env.NODE_ENV !== 'production';

// Pre-render all SPA routes as static HTML files during build.
// The root route maps to `{ slug: [] }` — the Next 16-documented form for the
// `[[...slug]]` root segment; `{ slug: undefined }` is rejected by export
// validation and makes every request after the first 404 fail with HTTP 500.
export function generateStaticParams() {
  const routes = [
    '',
    'about',
    'admin',
    'departments',
    'admission',
    'teachers',
    'notices',
    'events',
    'gallery',
    'donation',
    'blog',
    'contact',
    'results',
    'syllabus',
    'class-routine',
    'hifz',
    'exam',
    'calendar',
    'alumni',
    'prayer',
    'hadith',
    'quran',
    'fee-payment',
    'admission-track',
    'library',
    'attendance',
    'hostel',
    'dawah',
    'materials',
    'student',
    // URL aliases - redirect to correct pages (handled client-side)
    'student-portal',
    'articles',
    'article',
    'students',
    'teachers-list',
    'teacher',
    'notice',
    'event',
    'photo',
    'photos',
    'donate',
    'contact-us',
    'result',
    'exam-results',
    'routine',
    'pay',
  ];

  return routes.map((slug) => ({ slug: slug ? slug.split('/') : [] }));
}

export default function CatchAllPage() {
  return <ClientPage />;
}
