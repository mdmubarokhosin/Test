import ZAI from '/home/z/.bun/install/global/node_modules/z-ai-web-dev-sdk/dist/index.js';
import fs from 'fs';

async function main() {
  const zai = await ZAI.create();
  const b64 = fs.readFileSync('/home/z/my-project/public/logo.png').toString('base64');
  const dataUrl = `data:image/png;base64,${b64}`;

  const response = await zai.images.generations.edit({
    prompt:
      'Recolor this logo: change all dark green elements (graduation cap, open book cover, book outlines) to vivid bright blue color #0485f7. Change all golden mustard yellow elements (circular ring border, tassel, book text lines) to warm amber orange #f5a524. Keep pure white background, keep the exact same composition, shapes and design, only change the colors.',
    images: [{ url: dataUrl }],
    size: '1024x1024',
  });

  const out = response.data[0].base64;
  fs.writeFileSync('/home/z/my-project/public/logo-heroui.png', Buffer.from(out, 'base64'));
  console.log('OK: saved /home/z/my-project/public/logo-heroui.png');
}

main().catch((e) => {
  console.error('FAIL:', e?.message || e);
  process.exit(1);
});
